import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../Controllers/DepenseController.dart';
import '../models/Depense.dart';

class StatistiqueAnnee extends StatefulWidget {
  @override
  _TotalChartState createState() => _TotalChartState();
}

class _TotalChartState extends State<StatistiqueAnnee> {
  final DepenseController _depenseController = DepenseController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Total Expenses Chart'),
      ),
      body: Container(
        color: Colors.white, // Set the background color to white
        child: FutureBuilder<List<CategoryData>>(
          future: _loadCategoriesData(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else {
              final categories = snapshot.data ?? [];
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildChart(categories),
                  const SizedBox(height: 20),
                  ...categories.map((category) => _buildExpenseCard(category)),
                ],
              );
            }
          },
        ),
      ),
    );
  }

  Future<List<CategoryData>> _loadCategoriesData() async {
    List<CategoryData> categories = [];
    DateTime now = DateTime.now();
    int currentYear = now.year;

    for (int year = currentYear - 3; year <= currentYear; year++) {
      List<Depense> yearDepenses = await _depenseController.getDepensesForYear(year);
      double yearTotal = _calculateTotalExpenses(yearDepenses);

      categories.add(CategoryData(title: year.toString(), totalAmount: yearTotal, color: _getYearColor(year)));
    }

    return categories;
  }

  double _calculateTotalExpenses(List<Depense> depenses) {
    return depenses.fold(0.0, (sum, depense) => sum + depense.getPrix);
  }

  Color _getYearColor(int year) {
    // You can define your own colors based on years
    // This is just an example
    if (year == DateTime.now().year) {
      return Colors.blue;
    } else {
      return Colors.grey;
    }
  }

  Widget _buildChart(List<CategoryData> categories) {
    final total = categories.fold(0.0, (sum, category) => sum + category.totalAmount);

    return Expanded(
      flex: 2,
      child: Row(
        children: [
          Expanded(
            flex: 60,
            child: PieChart(
              PieChartData(
                centerSpaceRadius: 20.0,
                sections: total != 0
                    ? categories
                    .map(
                      (e) => PieChartSectionData(
                    showTitle: false,
                    value: e.totalAmount,
                    color: e.color,
                  ),
                )
                    .toList()
                    : [],
              ),
            ),
          ),
          Expanded(
            flex: 40,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FittedBox(
                  alignment: Alignment.center,
                  fit: BoxFit.scaleDown,
                  child: Text(
                    'Total Expenses: ${NumberFormat.currency(locale: 'en_IN', symbol: 'dh').format(total)}',
                    textScaleFactor: 1.5,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExpenseCard(CategoryData category) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: ListTile(
        title: Text(category.title),
        subtitle: Text('Total Amount: ${NumberFormat.currency(locale: 'en_IN', symbol: 'dh').format(category.totalAmount)}'),
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: category.color,
          ),
        ),
      ),
    );
  }
}

class CategoryData {
  final String title;
  final double totalAmount;
  final Color color;

  const CategoryData({required this.title, required this.totalAmount, required this.color});
}